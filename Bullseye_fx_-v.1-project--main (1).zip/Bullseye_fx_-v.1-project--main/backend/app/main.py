from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.database import Base, engine # adjust import path to your db file
from app.database.init_db import init_db
from app.routes.auth import router as auth_router
from app.routes.trades import router as trades_router
from app.routes.dashboard import router as dashboard_router


app = FastAPI(
    title="Bullseye FX API",
    description="Backend API for Bullseye FX Trading Journal",
    version="1.0.0",
)


# CORS - allow local development and Cloud Shell Web Preview
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://localhost:3002",
    ],
    allow_origin_regex=r"https://3000-.*\.cloudshell\.dev",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Create database tables
init_db()


# Routes
app.include_router(auth_router)
app.include_router(trades_router)
app.include_router(dashboard_router)


@app.get("/")
def root():
    return {
        "message": "Welcome to Bullseye FX API 🚀"
    }


@app.get("/health")
def health():
    return {
        "status": "healthy"
    }
