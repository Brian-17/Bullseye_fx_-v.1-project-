'use client';

import { useEffect, useState, useCallback } from "react";
import { useRouter } from "next/navigation";
import { api } from "@/lib/Api";
import RiskRewardCalculator from "../../components/dashboard/RiskRewardCalculator";
import BullseyeSetupBuilder from "../../components/dashboard/BullseyeSetupBuilder";
import EconomicCalendar from "../../components/dashboard/EconomicCalendar";
import AISignalPanel from "../../components/dashboard/AISignalPanel";
import MarketOverview from "../../components/dashboard/MarketOverview";
import StatsCard from "../../components/dashboard/StatsCard";
import PerformanceChart from "../../components/dashboard/PerformanceChart";
import RecentTrades from "../../components/dashboard/RecentTrades";

type Stats = {
  total_trades: number;
  winning_trades: number;
  losing_trades: number;
  win_rate: number;
  total_profit: number;
  average_profit: number;
  profit_factor: number;
  average_rr: number;
  best_pair: string;
  best_strategy: string;
  best_session: string;
}

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats>({
    total_trades: 0, winning_trades: 0, losing_trades: 0, win_rate: 0,
    total_profit: 0, average_profit: 0, profit_factor: 0, average_rr: 0,
    best_pair: "-", best_strategy: "-", best_session: "-"
  });
  const [trades, setTrades] = useState([]);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [statsData, tradesData] = await Promise.all([
        api("/dashboard/stats"),
        api("/trades?limit=5")
      ]);
      setStats(statsData);
      setTrades(tradesData);
    } catch (err) {
      localStorage.removeItem("token"); // changed
      router.push("/login");
    } finally {
      setLoading(false);
    }
  }, [router]);

  useEffect(() => {
    const token = localStorage.getItem("token"); // changed from access_token
    if (!token) {
      router.push("/login");
      return;
    }
    fetchData();
  }, [router, fetchData]);

  function handleLogout() {
    localStorage.removeItem("token"); // changed from access_token
    router.push("/login");
  }

  if (loading) {
    return <p style={{textAlign:"center", marginTop: 50}}>Loading dashboard...</p>;
  }

  return (
    <main style={{ padding: "40px", background: "#f8fafc", minHeight: "100vh" }}>
      <div style={{display:"flex", justifyContent:"space-between", alignItems:"center"}}>
        <h1>Bullseye FX Dashboard</h1>
        <button
          onClick={handleLogout}
          style={{ padding:"10px 20px", background:"#ef4444", color:"#fff", border:"none", borderRadius:"8px", cursor:"pointer", fontWeight:"bold" }}
        >
          Logout
        </button>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: "20px", marginTop: "30px" }}>
        <StatsCard title="Total Trades" value={stats.total_trades} />
        <StatsCard title="Wins" value={stats.winning_trades} />
        <StatsCard title="Losses" value={stats.losing_trades} />
        <StatsCard title="Win Rate" value={`${stats.win_rate.toFixed(1)}%`} />
        <StatsCard title="Total Profit" value={`$${stats.total_profit.toFixed(2)}`} />
        <StatsCard title="Avg Profit" value={`$${stats.average_profit.toFixed(2)}`} />
        <StatsCard title="Profit Factor" value={stats.profit_factor.toFixed(2)} />
        <StatsCard title="Avg R:R" value={`1:${stats.average_rr.toFixed(2)}`} />
        <StatsCard title="Best Pair" value={stats.best_pair} />
        <StatsCard title="Best Strategy" value={stats.best_strategy} />
        <StatsCard title="Best Session" value={stats.best_session} />
      </div>

      <PerformanceChart data={trades} />
      <MarketOverview />
      <RecentTrades trades={trades} onRefresh={fetchData} /> {/* Added onRefresh */}
      <AISignalPanel />
      <EconomicCalendar />
      <BullseyeSetupBuilder />
      <RiskRewardCalculator />
    </main>
  );
}
