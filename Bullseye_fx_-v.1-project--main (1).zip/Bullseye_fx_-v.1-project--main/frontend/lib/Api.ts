const API_BASE_URL =
  typeof window !== "undefined"
    ? `https://${window.location.hostname.replace(/^3000-/, "8000-")}`
    : "http://127.0.0.1:8000";

function getToken() {
  if (typeof window === "undefined") {
    return null;
  }

  return localStorage.getItem("access_token");
}

export async function api(
  path: string,
  options: RequestInit = {}
) {
  const token = getToken();

  const headers: HeadersInit = {
    "Content-Type": "application/json",
    ...options.headers,
  };

  if (token) {
    headers["Authorization"] = `Bearer ${token}`;
  }

  const response = await fetch(
    `${API_BASE_URL}${path}`,
    {
      ...options,
      headers,
    }
  );

  if (!response.ok) {
    const error = await response
      .json()
      .catch(() => ({
        detail: "Request failed",
      }));

    throw new Error(
      error.detail || "Request failed"
    );
  }

  if (response.status === 204) {
    return null;
  }

  return response.json();
}

export async function getTrades() {
  return api("/trades/");
}

export async function getDashboardStats() {
  return api("/dashboard/stats");
}
