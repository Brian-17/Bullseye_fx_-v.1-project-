"use client";

import { useEffect, useState } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

import { getTrades } from "../../lib/Api";

type Trade = {
  id: number;
  pair: string;
  profit_loss: number | null;
  created_at: string;
};

type PerformancePoint = {
  date: string;
  profit: number;
};

export default function PerformanceChart() {
  const [data, setData] = useState<PerformancePoint[]>([]);
  const [error, setError] = useState("");

  useEffect(() => {
    async function loadPerformance() {
      try {
        const trades: Trade[] = await getTrades();

        const sortedTrades = [...trades].sort(
          (a, b) =>
            new Date(a.created_at).getTime() -
            new Date(b.created_at).getTime()
        );

        let cumulativeProfit = 0;

        const performance = sortedTrades.map((trade) => {
          cumulativeProfit += trade.profit_loss ?? 0;

          return {
            date: new Date(trade.created_at).toLocaleDateString(),
            profit: Number(cumulativeProfit.toFixed(2)),
          };
        });

        setData(performance);
      } catch (err) {
        console.error(err);
        setError("Unable to load trading performance.");
      }
    }

    loadPerformance();
  }, []);

  return (
    <div
      style={{
        background: "#ffffff",
        padding: "25px",
        borderRadius: "12px",
        marginTop: "30px",
        boxShadow: "0 2px 8px rgba(0,0,0,0.08)",
      }}
    >
      <h2>Trading Performance</h2>

      {error && (
        <p style={{ color: "red" }}>
          {error}
        </p>
      )}

      {!error && data.length === 0 && (
        <div
          style={{
            height: "300px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            color: "#64748b",
          }}
        >
          No trading data available yet.
        </div>
      )}

      {data.length > 0 && (
        <div style={{ width: "100%", height: "300px" }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />

              <XAxis dataKey="date" />

              <YAxis />

              <Tooltip
                formatter={(value) => [
                  `$${Number(value).toFixed(2)}`,
                  "Cumulative Profit",
                ]}
              />

              <Line
                type="monotone"
                dataKey="profit"
                stroke="#f59e0b"
                strokeWidth={3}
                dot={{ r: 4 }}
                activeDot={{ r: 6 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
        }
