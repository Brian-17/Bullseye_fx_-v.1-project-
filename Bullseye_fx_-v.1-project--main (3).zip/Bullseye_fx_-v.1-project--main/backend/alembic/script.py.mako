"""${message}

Revision ID: ${up_revision}
Revises: ${down_revision | comma,n}
Create Date: ${create_date}

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
<<<<<<< HEAD

=======
>>>>>>> c2e764e (Fix auth_crud and project errors)
${imports if imports else ""}

# revision identifiers, used by Alembic.
revision = ${repr(up_revision)}
down_revision = ${repr(down_revision)}
branch_labels = ${repr(branch_labels)}
depends_on = ${repr(depends_on)}


def upgrade() -> None:
    ${upgrades if upgrades else "pass"}


def downgrade() -> None:
<<<<<<< HEAD
    ${downgrades if downgrades else "pass"}
=======
    ${downgrades if downgrades else "pass"}
>>>>>>> c2e764e (Fix auth_crud and project errors)
