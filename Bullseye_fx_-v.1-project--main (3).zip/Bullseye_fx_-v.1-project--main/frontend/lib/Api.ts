const API_URL = "http://localhost:8000";

function getToken() {
  if (typeof window === "undefined") {
    return null;
  }

  return localStorage.getItem("access_token");
}

async function apiFetch(path: string) {
  const token = getToken();

  const response = await fetch(`${API_URL}${path}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  if (!response.ok) {
    throw new Error(`API request failed: ${response.status}`);
  }

  return response.json();
}

export async function getTrades() {
  return apiFetch("/trades/");
}

export async function getDashboardStats() {
  return apiFetch("/dashboard/stats");
}
